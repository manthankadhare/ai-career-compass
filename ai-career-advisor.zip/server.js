// =============================================
// server.js - Main Backend File
// AI Career Growth Advisor
// =============================================

// Load environment variables from .env file
require("dotenv").config();

const express = require("express");
const cors = require("cors");
const path = require("path");
const Anthropic = require("@anthropic-ai/sdk");

// Create Express app
const app = express();
const PORT = process.env.PORT || 3000;

// ---- Middleware Setup ----
app.use(cors()); // Allow requests from frontend
app.use(express.json()); // Parse JSON request bodies
app.use(express.static(path.join(__dirname, "public"))); // Serve HTML/CSS/JS files

// Create Anthropic AI client
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

// =============================================
// POST /api/career-advice
// Main route: receives user input, returns AI career plan
// =============================================
app.post("/api/career-advice", async (req, res) => {
  // Extract data from the form submission
  const { name, education, skills, interests, goals, experience } = req.body;

  // Basic input validation
  if (!name || !skills || !interests || !goals) {
    return res.status(400).json({
      error: "Please fill in all required fields (name, skills, interests, goals).",
    });
  }

  // Build a detailed prompt for Claude AI
  // The better the prompt, the better the response!
  const userPrompt = `
You are an expert career counselor helping a student plan their tech career.

Here is information about the student:
- Name: ${name}
- Education Level: ${education || "Not specified"}
- Current Skills: ${skills}
- Interests: ${interests}
- Career Goals: ${goals}
- Experience: ${experience || "Beginner / No experience yet"}

Please create a detailed, personalized career growth plan. 
Respond ONLY in this exact JSON format (no extra text, no markdown):

{
  "summary": "A warm, personalized 2-3 sentence summary addressing ${name} directly about their career potential",
  "careerPaths": [
    {
      "title": "Career Path Title (e.g., Full Stack Developer)",
      "match": "High/Medium/Low",
      "description": "Why this career fits them in 2 sentences",
      "avgSalary": "Estimated salary range in INR/USD",
      "topCompanies": ["Company1", "Company2", "Company3"]
    }
  ],
  "skillsToLearn": [
    {
      "skill": "Skill name",
      "priority": "High/Medium/Low",
      "reason": "Why they need this skill",
      "freeResource": "A specific free resource to learn it (e.g., freeCodeCamp, Coursera, YouTube channel)"
    }
  ],
  "roadmap": {
    "beginner": {
      "duration": "0-3 months",
      "goals": ["Goal 1", "Goal 2", "Goal 3"],
      "project": "A simple beginner project idea they can build"
    },
    "intermediate": {
      "duration": "3-9 months",
      "goals": ["Goal 1", "Goal 2", "Goal 3"],
      "project": "An intermediate project idea that demonstrates real skills"
    },
    "advanced": {
      "duration": "9-18 months",
      "goals": ["Goal 1", "Goal 2", "Goal 3"],
      "project": "An advanced capstone project for portfolio/job applications"
    }
  },
  "internshipTips": [
    "Tip 1 specific to their profile",
    "Tip 2 specific to their profile",
    "Tip 3 specific to their profile"
  ],
  "motivationalQuote": "A relevant, inspiring quote for their journey"
}
`;

  try {
    console.log(`\n📋 Generating career plan for: ${name}`);
    console.log(`Skills: ${skills}`);
    console.log(`Goals: ${goals}\n`);

    // Call Claude AI API
    const message = await anthropic.messages.create({
      model: "claude-sonnet-4-20250514", // Using Claude Sonnet - great quality + speed
      max_tokens: 2000,
      messages: [
        {
          role: "user",
          content: userPrompt,
        },
      ],
    });

    // Extract the text response from Claude
    const responseText = message.content[0].text;

    // Parse JSON (Claude returns clean JSON as instructed)
    let careerPlan;
    try {
      // Remove any accidental markdown code fences if present
      const cleanJson = responseText.replace(/```json\n?|\n?```/g, "").trim();
      careerPlan = JSON.parse(cleanJson);
    } catch (parseError) {
      console.error("JSON parse error:", parseError);
      // If parsing fails, return the raw text with a flag
      return res.status(500).json({
        error: "AI response was not in expected format. Please try again.",
        raw: responseText,
      });
    }

    console.log(`✅ Career plan generated successfully for ${name}`);

    // Send the career plan back to frontend
    res.json({
      success: true,
      careerPlan: careerPlan,
    });
  } catch (error) {
    console.error("❌ API Error:", error.message);

    // Handle specific API errors with helpful messages
    if (error.status === 401) {
      return res.status(401).json({
        error: "Invalid API key. Please check your ANTHROPIC_API_KEY in the .env file.",
      });
    } else if (error.status === 429) {
      return res.status(429).json({
        error: "Rate limit reached. Please wait a moment and try again.",
      });
    } else {
      return res.status(500).json({
        error: "Something went wrong. Please try again. Error: " + error.message,
      });
    }
  }
});

// =============================================
// GET / - Serve the main HTML page
// =============================================
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// =============================================
// Start the server
// =============================================
app.listen(PORT, () => {
  console.log("\n🚀 AI Career Advisor Server Started!");
  console.log(`📍 Open your browser: http://localhost:${PORT}`);
  console.log(`🔑 API Key loaded: ${process.env.ANTHROPIC_API_KEY ? "✅ Yes" : "❌ Not found - check .env file"}`);
  console.log("\nPress Ctrl+C to stop the server.\n");
});
